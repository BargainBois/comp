/*
  BadUSB.cpp - Library for BadUSB code.
  Created by Connor Beam, February 23, 2018.
  Under The Creative Commons Act.
*/

#include "Arduino.h"
#include "BadUSB.h"
#include "Keyboard.h"

BadUSB::BadUSB()
{
  pinMode(9, INPUT_PULLUP);
  pinMode(LED_BUILTIN, OUTPUT);
  _pin = LED_BUILTIN;
  _DefaultDelay = 250;
  _EnterDelay = 750;
  _buttonpin = 11;
}

void BadUSB::SetEnterDelay(int DELAYTIME)
{
  _EnterDelay = DELAYTIME;
}
void BadUSB::SetDefaultDelay(int DELAYTIME)
{
  _DefaultDelay = DELAYTIME;
}
void BadUSB::BlinkLED(int blinktimes, int blinkdelay)
{
  for (int i=0; i < blinktimes; i++){
      digitalWrite(_pin, 1);
      delay(blinkdelay);
      digitalWrite(_pin, 0);
      delay(_DefaultDelay);
   }
}

void BadUSB::TypeString(String MyString)
{
    Keyboard.print(MyString);
    delay(_DefaultDelay);
}

void BadUSB::EnterString(String MyString)
{
    Keyboard.print(MyString);
    delay(_EnterDelay);
    Keyboard.press(KEY_RETURN);
    delay(100);
    Keyboard.releaseAll();
    delay(_DefaultDelay);
}

void BadUSB::ChangeLED(int hrl){
    digitalWrite(_pin, hrl);
    delay(_DefaultDelay);
}

void BadUSB::PressKey(char KEYNAME){
  Keyboard.press(KEYNAME);
  delay(100);
  Keyboard.release(KEYNAME);
  delay(_DefaultDelay);
}

void BadUSB::DelayDefault()
{
  delay(_DefaultDelay);
}

void BadUSB::WaitForButtonPress()
{
  while (digitalRead(_buttonpin) == HIGH) {
  }
}