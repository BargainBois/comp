#ifndef BadUSB_h
#define BadUSB_h
#include "Arduino.h"
#include "Keyboard.h"
class BadUSB
{
  public:
    BadUSB();
    void SetEnterDelay(int DELAYTIME);
    void SetDefaultDelay(int DELAYTIME);
	void BlinkLED(int blinktimes, int blinkdelay);
	void TypeString(String MyString);
	void EnterString(String MyString);
	void ChangeLED(int hrl);
	void PressKey(char KEYNAME);
	void DelayDefault();
	void WaitForButtonPress();
  private:
    int _pin;
	int _DefaultDelay;
	int _EnterDelay;
	int _buttonpin;
};
#endif
